package com.example.dob_intertech_final;

import android.graphics.Bitmap;
import android.os.Environment;
import android.telecom.Call;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CallServer {

    public void sendDatabase(Bitmap onyuz_bitmap, Bitmap arkayuz_bitmap) throws FileNotFoundException {

        Log.i("DEV","on yazi save");

        File img1 = new File(Environment.getExternalStorageDirectory(), "onyuz_bitmap.jpeg");
        File img2 = new File(Environment.getExternalStorageDirectory(), "arkayuz_bitmap.jpeg");

        try {
            FileOutputStream outputStream = new FileOutputStream(img1);
            FileOutputStream outputStreamm = new FileOutputStream(img1);

            onyuz_bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);

            outputStreamm = new FileOutputStream(img2);
            arkayuz_bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStreamm);


            outputStream.close();
            outputStream.close();

        } catch (IOException e) {
            Log.e("DEV", "Error saving bitmap image: " + e.getMessage());

        }

// Call sendImage with the Bitmap image as a file and the resource ID
        MyApplication app = new MyApplication();
        MyRepo repo = new MyRepo();
        repo.sendImage(app.srv, img1, img2);
    }



}