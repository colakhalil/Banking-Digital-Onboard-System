package com.example.dob_intertech_final;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Onyuz extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onyuz);

        View ellipseView = (View)findViewById(R.id.ellipse_1);

        ellipseView.setOnClickListener(v->{
            Intent intent = new Intent(Onyuz.this, Arkayuz.class);

            startActivity(intent);
        });
    }
}