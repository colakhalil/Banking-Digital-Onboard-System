package com.example.dob_intertech_final;

import static com.example.dob_intertech_final.ArkaYuzCekim.arkayuz_bitmap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.ImageView;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.io.FileNotFoundException;


import java.io.FileNotFoundException;

public class UserCekimKontrol extends AppCompatActivity {

    boolean flag = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_cekim_kontrol);


        Button btnDevam = findViewById(R.id.btnDevam);

        //You may send here tı the database
        CallServer call = new CallServer();
        try {
            call.sendDatabase(OnYuzCekim.onyuz_bitmap, UserCekim.photo_bitmap);

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        btnDevam.setOnClickListener(v->{

            if(!flag){

                TextView txt = findViewById(R.id.l_tfen_kiml);
                txt.setText("Kontroller Yapılırken Lütfen Bekleyiniz...");
                Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        // Programmatically perform button click action
                        flag = true;
                        btnDevam.performClick();
                    }
                }, 5000); // Delay in milliseconds

            }

            else if(ServerInfo.isPhoto){

                Intent i = new Intent(UserCekimKontrol.this, Finish.class);
                startActivity(i);
                flag = false;
            }
            else if(flag) {
                TextView text = findViewById(R.id.l_tfen_kiml);
                myButtonOnClickWorking(text);
                flag = false;
            }



        });



        ImageView imageView = findViewById(R.id.imgKontrol); // Assuming you have an ImageView in your layout

        // Get the shared image data from the incoming intent
        Intent receivedIntent = getIntent();
        if (receivedIntent != null && Intent.ACTION_SEND.equals(receivedIntent.getAction())) {
            Uri imageUri = receivedIntent.getParcelableExtra(Intent.EXTRA_STREAM);

            // Rotate the shared image by 90 degrees to the left
            Bitmap rotatedBitmap = rotateBitmap90Degrees(imageUri);

            // Load the rotated image into the ImageView
            if (rotatedBitmap != null) {
                imageView.setImageBitmap(rotatedBitmap);
            }
        }

    }

    private Bitmap rotateBitmap90Degrees(Uri imageUri) {
        try {
            Bitmap originalBitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
            android.graphics.Matrix matrix = new android.graphics.Matrix();
            matrix.postRotate(90); // Rotate left by 90 degrees
            return Bitmap.createBitmap(originalBitmap, 0, 0, originalBitmap.getWidth(), originalBitmap.getHeight(), matrix, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public void myButtonOnClickWorking(View view) {

        MyApplication app = new MyApplication();
        MyRepo repo = new MyRepo();

        repo.send(app.srv);
        // step 1
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.pop_up2, null);

        // step 2
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true;
        PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

        // step 3
        popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);

        Button btntamam = popupView.findViewById(R.id.btntamam); // Find the button within the popup layout
        btntamam.setOnClickListener(v -> {
            Intent i = new Intent(UserCekimKontrol.this, User.class);
            startActivity(i);
        });
    }
}