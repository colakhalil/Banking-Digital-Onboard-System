package com.example.dob_intertech_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class User extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        View ellipseView = (View)findViewById(R.id.ellipse_1);

        ellipseView.setOnClickListener(v->{
            Intent intent = new Intent(User.this, UserCekim.class);
            startActivity(intent);
        });
    }
}