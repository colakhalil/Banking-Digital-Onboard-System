package com.example.dob_intertech_final;


import android.content.Context;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MyRepo {

    public void sendImage(ExecutorService srv, File imageFile1, File imageFile2) {
        srv.submit(() -> {

            OkHttpClient client = new OkHttpClient();

            // Change the IP address and port to match your server's address
            String serverUrl = "http://192.168.1.108:5000/image";

            // Prepare the image file to send to the server
            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("image", imageFile1.getName(),
                            RequestBody.create(MediaType.parse("image/jpeg"), imageFile1))
                    .addFormDataPart("image2", imageFile2.getName(),
                            RequestBody.create(MediaType.parse("image/jpeg"), imageFile2))
                    .build();

            // Prepare the request
            Request request = new Request.Builder()
                    .url(serverUrl)
                    .post(requestBody)
                    .build();

            // Send the request asynchronously
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    // Handle the failure here
                    Log.e("DEV", "Error sending image: " + e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    // Handle the server response here
                    if (response.isSuccessful()) {
                        String responseBody = response.body().string();
                        Log.i("DEV", "Server response: " + responseBody);
                        try {
                            JSONObject jsonObject = new JSONObject(responseBody);

                            ServerInfo.arkayuzShape = jsonObject.optBoolean("arkayuzShape");
                            ServerInfo.onyuzShape = jsonObject.optBoolean("onyuzShape");
                            ServerInfo.isOnYuzReadable = jsonObject.optBoolean("isOnYuzReadable");
                            ServerInfo.isArkaYuzReadable = jsonObject.optBoolean("isArkaYuzReadable");
                            ServerInfo.isPhoto = jsonObject.optBoolean("isPhoto");
                            ServerInfo.isTC = jsonObject.optBoolean("isTC");

                            ServerInfo.adi = jsonObject.getString("adi");
                            ServerInfo.soyadi = jsonObject.getString("soyadi");
                            ServerInfo.cinsiyeti = jsonObject.getString("cinsiyeti");
                            ServerInfo.dogumTarihi = jsonObject.getString("dogumTarihi");
                            ServerInfo.anneAdi = jsonObject.getString("anneAdi");
                            ServerInfo.TC = jsonObject.getString("TC");
                            ServerInfo.uyruk = jsonObject.getString("uyruk");
                            ServerInfo.seriNo = jsonObject.getString("seriNo");
                            ServerInfo.pen = jsonObject.getString("pen");
                            ServerInfo.babaAdi = jsonObject.getString("babaAdi");
                            ServerInfo.yuzde = jsonObject.getString("yuzde");



                            Log.i("DEV", "arkayuzShape: " + ServerInfo.arkayuzShape);
                            Log.i("DEV", "onyuzShape: " + ServerInfo.onyuzShape);
                            Log.i("DEV", "isOnYuzReadable: " + ServerInfo.isOnYuzReadable);
                            Log.i("DEV", "isArkaYuzReadable: " + ServerInfo.isArkaYuzReadable);
                            Log.i("DEV", "isPhoto: " + ServerInfo.isPhoto);
                            Log.i("DEV", "Yuzde: " + ServerInfo.yuzde);
                            Log.i("DEV", "isTC: " + ServerInfo.isTC);

                            Log.i("DEV", "adi: " + ServerInfo.adi);
                            Log.i("DEV", "Soyadi: " + ServerInfo.soyadi);
                            Log.i("DEV", "cinsiyeti: " + ServerInfo.cinsiyeti);
                            Log.i("DEV", "dogumTarihi: " + ServerInfo.dogumTarihi);
                            Log.i("DEV", "anneAdi: " + ServerInfo.anneAdi);
                            Log.i("DEV", "TC: " + ServerInfo.TC);
                            Log.i("DEV", "uyruk: " + ServerInfo.uyruk);
                            Log.i("DEV", "seriNo: " + ServerInfo.seriNo);
                            Log.i("DEV", "pen: " + ServerInfo.pen);
                            Log.i("DEV", "babaAdi: " + ServerInfo.babaAdi);


                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }


                    } else {
                        Log.e("DEV", "Server error: " + response.code() + " " + response.message());
                    }
                }
            });
        });
    }
    public void send(ExecutorService srv) {
        srv.submit(() -> {
            try {
                // Define the server URL
                String serverUrl = "http://192.168.1.108:5000/image"; // Replace with your server URL

                // Create the connection to the server
                URL url = new URL(serverUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                // Set the request method
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);

                // Send the request
                DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                outputStream.flush();
                outputStream.close();

                // Get the response from the server
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Handle the successful response if needed
                    // ...
                } else {
                    // Handle the error response
                    // ...
                }

                // Disconnect the connection
                connection.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }


}
