package com.example.dob_intertech_final;

public class ServerInfo {

    public static Boolean arkayuzShape= false;
    public static Boolean onyuzShape= false;
    public static Boolean isOnYuzReadable= false;
    public static Boolean isArkaYuzReadable= false;
    public static Boolean isPhoto= false;
    public static Boolean isTC = false;

    public static String adi = "";
    public static String soyadi = "";
    public static String cinsiyeti = "";
    public static String dogumTarihi = "";
    public static String anneAdi = "";
    public static String TC = "";
    public static String uyruk = "";
    public static String seriNo = "";
    public static String pen = "";

    public static String babaAdi = "";

    public static String yuzde = "";
}
