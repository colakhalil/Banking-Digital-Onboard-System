package com.example.dob_intertech_final;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Finish extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finish);

        TextView txtAdi = findViewById(R.id.txtAdi);
        txtAdi.setText("Adı: " + ServerInfo.adi);

        TextView txtSoyadi = findViewById(R.id.txtSoyadi);
        txtSoyadi.setText("Soyadı: " + ServerInfo.soyadi);

        TextView txtCinsiyet = findViewById(R.id.txtCinsiyet);
        txtCinsiyet.setText("Cinsiyeti: " + ServerInfo.cinsiyeti);

        TextView txtDogum = findViewById(R.id.txtDogum);
        txtDogum.setText("Doğum Tarihi: " + ServerInfo.dogumTarihi);

        TextView txtAnne = findViewById(R.id.txtAnne);
        txtAnne.setText("Anne Adı: " + ServerInfo.anneAdi);

        TextView txtTC = findViewById(R.id.txtTC);
        txtTC.setText("TC: " + ServerInfo.TC);

        TextView txtUyruk = findViewById(R.id.txtUyruk);
        txtUyruk.setText("Uyruk: " + ServerInfo.uyruk);

        TextView txtSeri = findViewById(R.id.txtSeri);
        txtSeri.setText("Seri No: " + ServerInfo.seriNo);

        TextView txtPen = findViewById(R.id.txtPen);
        txtPen.setText("Pen No: " + ServerInfo.pen);

        TextView txtBaba = findViewById(R.id.txtBaba);
        txtBaba.setText("Baba Adı: " + ServerInfo.babaAdi);

        ImageView imgOn = findViewById(R.id.imgOn);
        imgOn.setImageBitmap(OnYuzCekim.onyuz_bitmap);

        ImageView imgArka = findViewById(R.id.imgArka);
        imgArka.setImageBitmap(ArkaYuzCekim.arkayuz_bitmap);

        TextView txtYuzde = findViewById(R.id.txtYuzde);
        txtYuzde.setText("Fotograflar %" + ServerInfo.yuzde + " benzerlikle eşleşiyor.");

    }
}