package com.example.dob_intertech_final;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Giris extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_giris);
        Button btnMusteri= findViewById(R.id.btnMusteri);

        btnMusteri.setOnClickListener(v->{

            Intent intent = new Intent(Giris.this, Tanitim.class);
            startActivity(intent);


        });
    }
}