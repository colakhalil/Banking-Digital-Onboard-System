package com.example.dob_intertech_final;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;


public class KimlikPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kimlikpage);

        View ellipseView = (View)findViewById(R.id.ellipse_1);

        ellipseView.setOnClickListener(v->{
            Intent intent = new Intent(KimlikPage.this, Onyuz.class);

            startActivity(intent);
        });
    }
}