package com.example.dob_intertech_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class Tanitim extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tanitim);

        Button btn = findViewById(R.id.btnDevam);
        btn.setOnClickListener(v->{
            Intent i = new Intent(Tanitim.this, KimlikPage.class);
            startActivity(i);
        });
    }
}