package com.example.dob_intertech_final;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;

public class OnYuzCekimKontrol extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_on_yuz_cekim_kontrol);

        Button btnDevam = findViewById(R.id.btnDevam);


        btnDevam.setOnClickListener(v->{

            Intent i = new Intent(OnYuzCekimKontrol.this, ArkaYuzCekim.class);
            startActivity(i);


        });



        ImageView imageView = findViewById(R.id.imgKontrol); // Assuming you have an ImageView in your layout

        // Get the shared image data from the incoming intent
        Intent receivedIntent = getIntent();
        if (receivedIntent != null && Intent.ACTION_SEND.equals(receivedIntent.getAction())) {
            Uri imageUri = receivedIntent.getParcelableExtra(Intent.EXTRA_STREAM);

            // Rotate the shared image by 90 degrees to the left
            Bitmap rotatedBitmap = rotateBitmap90Degrees(imageUri);

            // Load the rotated image into the ImageView
            if (rotatedBitmap != null) {
                imageView.setImageBitmap(rotatedBitmap);
            }
        }



    }

    // Method to rotate a bitmap by 90 degrees to the left
    private Bitmap rotateBitmap90Degrees(Uri imageUri) {
        try {
            Bitmap originalBitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
            android.graphics.Matrix matrix = new android.graphics.Matrix();
            matrix.postRotate(90); // Rotate left by 90 degrees
            return Bitmap.createBitmap(originalBitmap, 0, 0, originalBitmap.getWidth(), originalBitmap.getHeight(), matrix, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
