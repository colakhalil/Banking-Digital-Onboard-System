package com.example.dob_intertech_final;


import android.app.Application;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyApplication extends Application {

    ExecutorService srv = Executors.newCachedThreadPool();

    public ExecutorService getSrv() {
        return srv;
    }


}
